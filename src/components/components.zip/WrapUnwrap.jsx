import React, { useEffect, useContext, useState } from 'react';
import { ethers } from 'ethers';
import { SwapButton } from '../styles/SwapStyles';
import { TokenContext } from '../contexts/TokenContext';
import { Web3Context } from '../contexts/Web3Context';

const WrapUnwrap = ({ tokenIn, tokenOut, amountIn, amountOut, setAmountOut, provider, WKRESTAddress, WrappedKRESTABI }) => {
  const { tokens } = useContext(TokenContext);
  const { account } = useContext(Web3Context);
  const [updateBalance, setUpdateBalance] = useState(false);

  useEffect(() => {
    setAmountOut(amountIn); // 1:1 ratio for wrapping/unwrapping
  }, [amountIn, setAmountOut]);

  useEffect(() => {
    if (updateBalance) {
      checkBalances();
      setUpdateBalance(false);
    }
  }, [updateBalance]);

  const handleWrapUnwrap = async () => {
    try {
      if (!amountIn || parseFloat(amountIn) <= 0) {
        alert('Please enter a valid amount');
        return;
      }
      const contract = new ethers.Contract(WKRESTAddress, WrappedKRESTABI, provider.getSigner());
      const tx = tokenIn === 'KRST'
        ? await contract.deposit({ value: ethers.utils.parseEther(amountIn) })
        : await contract.withdraw(ethers.utils.parseEther(amountIn));
      await tx.wait();
      alert(`${getTokenSymbol(tokenIn)} swapped to ${getTokenSymbol(tokenOut)} successfully`);
      setUpdateBalance(true);
    } catch (err) {
      console.error("Error wrapping/unwrapping tokens:", err);
      alert(`Error wrapping/unwrapping tokens: ${err.message}`);
    }
  };

  const getTokenSymbol = (address) => tokens[address]?.symbol || address;
  const getTokenLogo = (address) => tokens[address]?.logo || '';

  const checkBalances = async () => {
    if (account) {
      const balanceIn = tokenIn === 'KRST'
        ? await provider.getBalance(account)
        : await new ethers.Contract(tokens[tokenIn].address, WrappedKRESTABI, provider).balanceOf(account);
      const balanceOut = tokenOut === 'KRST'
        ? await provider.getBalance(account)
        : await new ethers.Contract(tokens[tokenOut].address, WrappedKRESTABI, provider).balanceOf(account);

      document.querySelector(`#balance-${tokenIn}`).innerText = ethers.utils.formatUnits(balanceIn, 18);
      document.querySelector(`#balance-${tokenOut}`).innerText = ethers.utils.formatUnits(balanceOut, 18);
    }
  };

  return (
    <>
      <SwapButton onClick={handleWrapUnwrap}>
        {tokenIn === 'KRST' ? 'Wrap KREST' : 'Unwrap KREST'}
      </SwapButton>
      <div>
        1 <img src={getTokenLogo(tokenIn === 'KRST' ? 'KRST' : WKRESTAddress)} alt="Token Logo" width="20" /> {getTokenSymbol(tokenIn === 'KRST' ? 'KRST' : WKRESTAddress)} 
        = 1 <img src={getTokenLogo(tokenOut === 'KRST' ? 'KRST' : WKRESTAddress)} alt="Token Logo" width="20" /> {getTokenSymbol(tokenOut === 'KRST' ? 'KRST' : WKRESTAddress)}
      </div>
    </>
  );
};

export default WrapUnwrap;
