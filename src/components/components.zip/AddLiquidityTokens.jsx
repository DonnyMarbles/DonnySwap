import React, { useState, useContext, useEffect } from 'react';
import { ethers } from 'ethers';
import { Web3Context } from '../contexts/Web3Context';
import { TokenContext } from '../contexts/TokenContext';
import { ABIContext } from '../contexts/ABIContext';
import {
    AddLiquidityContainer,
    AddLiquidityInputContainer,
    AddLiquidityButton,
    TokenInfo,
    NoLiquidityMessage,
    LPTokenBalance,
    ErrorMessage,
    ExchangeRate,
} from '../styles/AddLiquidityStyles';

const AddLiquidityTokens = ({ tokenA, tokenB, onTokenSelection, error }) => {
    const { provider, signer, account } = useContext(Web3Context);
    const { UniswapV2Router02ABI, UniswapV2PairABI, UniswapV2FactoryABI, ERC20ABI, WrappedKRESTABI } = useContext(ABIContext);
    const { tokens, routerAddress } = useContext(TokenContext);
    const [amountA, setAmountA] = useState('');
    const [amountB, setAmountB] = useState('');
    const [balanceA, setBalanceA] = useState('');
    const [balanceB, setBalanceB] = useState('');
    const [noLiquidity, setNoLiquidity] = useState(false);
    const [lpBalance, setLpBalance] = useState('');
    const [exchangeRate, setExchangeRate] = useState(null);
    const [allowanceA, setAllowanceA] = useState(ethers.constants.Zero);
    const [allowanceB, setAllowanceB] = useState(ethers.constants.Zero);
    const [needsApprovalA, setNeedsApprovalA] = useState(false);
    const [needsApprovalB, setNeedsApprovalB] = useState(false);

    useEffect(() => {
        if (tokenA && account && tokenA !== "") {
            checkBalance(tokenA, setBalanceA);
            checkAllowance(tokenA, setAllowanceA, setNeedsApprovalA, amountA);
        }
        if (tokenB && account && tokenB !== "") {
            checkBalance(tokenB, setBalanceB);
            checkAllowance(tokenB, setAllowanceB, setNeedsApprovalB, amountB);
        }
        if (tokenA && tokenB && tokenA !== tokenB && !((tokenA === 'KRST' && tokenB === 'WKREST') || (tokenA === 'WKREST' && tokenB === 'KRST')) && tokenA !== "" && tokenB !== "") {
            checkLPTokenBalance(tokenA, tokenB);
            calculateExchangeRate(tokenA, tokenB);
        }
    }, [tokenA, tokenB, account]);

    useEffect(() => {
        if (amountA && tokenA && tokenA !== "") {
            checkIfNeedsApproval(tokenA, amountA, allowanceA, setNeedsApprovalA);
        }
        if (amountB && tokenB && tokenB !== "") {
            checkIfNeedsApproval(tokenB, amountB, allowanceB, setNeedsApprovalB);
        }
    }, [amountA, amountB, tokenA, tokenB, allowanceA, allowanceB]);

    const getTokenAddress = (tokenSymbol) => {
        if (tokenSymbol === 'KRST') return null; // KRST is native token, no contract address
        const token = Object.values(tokens).find(token => token.symbol === tokenSymbol);
        return token ? token.address : null;
    };

    const getTokenDecimals = (tokenSymbol) => {
        const token = Object.values(tokens).find(token => token.symbol === tokenSymbol);
        return token ? token.decimals : 18;
    };

    const checkBalance = async (tokenSymbol, setBalance) => {
        try {
            let balance;
            const tokenAddress = getTokenAddress(tokenSymbol);
            if (!tokenAddress && tokenSymbol !== 'KRST') throw new Error(`Token address for ${tokenSymbol} not found`);
            if (tokenSymbol === 'KRST') {
                balance = await provider.getBalance(account);
            } else {
                const contract = new ethers.Contract(tokenAddress, ERC20ABI, provider);
                balance = await contract.balanceOf(account);
            }
            setBalance(ethers.utils.formatUnits(balance, getTokenDecimals(tokenSymbol)));
        } catch (err) {
            console.error('Error fetching balance:', err);
            setBalance('');
        }
    };

    const checkAllowance = async (tokenSymbol, setAllowance, setNeedsApproval, amount) => {
        try {
            if (amount === "") {
                return; // Skip check if token is not selected
            }
            const tokenAddress = getTokenAddress(tokenSymbol);
            if (!tokenAddress && tokenSymbol !== 'KRST') {
                throw new Error(`Token address for ${tokenSymbol} not found`);
            }
            if (tokenSymbol === 'KRST') {
                setAllowance(ethers.constants.MaxUint256); // Native token doesn't need allowance
            }
            if (tokenSymbol === 'WKREST') {
                const contract = new ethers.Contract(tokenAddress, WrappedKRESTABI, provider);
                const allowance = await contract.allowance(account, routerAddress);
                setAllowance(allowance);
                console.log(`Allowance for ${tokenSymbol}: ${allowance.toString()}`);
                checkIfNeedsApproval(tokenSymbol, amount, allowance, setNeedsApproval);
            } else {
                const contract = new ethers.Contract(tokenAddress, ERC20ABI, provider);
                const allowance = await contract.allowance(account, routerAddress);
                setAllowance(allowance);
                console.log(`Allowance for ${tokenSymbol}: ${allowance.toString()}`);
                checkIfNeedsApproval(tokenSymbol, amount, allowance, setNeedsApproval);
            }
        } catch (err) {
            console.error('Error fetching allowance:', err);
            setAllowance(ethers.constants.Zero);
            setNeedsApproval(true);
        }
    };

    const checkIfNeedsApproval = (tokenSymbol, amount, allowance, setNeedsApproval) => {
        if (tokenSymbol === "") {
            return; // Skip check if token is not selected
        }
        const tokenAddress = getTokenAddress(tokenSymbol);
        if (!tokenAddress && tokenSymbol !== 'KRST') {
            console.error(`Token address for ${tokenSymbol} not found`);
            setNeedsApproval(true);
            return;
        } if (tokenSymbol === 'WKREST') {
            const decimals = getTokenDecimals(tokenSymbol);
            const amountParsed = ethers.utils.parseUnits(amount, decimals);
            console.log(`Amount parsed for ${tokenSymbol}: ${amountParsed}, Allowance: ${allowance}`);
            setNeedsApproval(amountParsed.gt(allowance));
        }
        const decimals = getTokenDecimals(tokenSymbol);
        const amountParsed = ethers.utils.parseUnits(amount, decimals);
        console.log(`Amount parsed for ${tokenSymbol}: ${amountParsed}, Allowance: ${allowance}`);
        setNeedsApproval(amountParsed.gt(allowance));
    };

    const handleApprove = async (tokenSymbol, amount) => {
        try {
            const tokenAddress = getTokenAddress(tokenSymbol);
            if (!tokenAddress) throw new Error(`Token address for ${tokenSymbol} not found`);
            const contract = new ethers.Contract(tokenAddress, ERC20ABI, signer);
            const amountParsed = ethers.utils.parseUnits(amount, getTokenDecimals(tokenSymbol));
            console.log(`Approving ${amountParsed.toString()} of ${tokenSymbol}`);
            const tx = await contract.approve(routerAddress, amountParsed);
            await tx.wait();
            if (tokenSymbol === tokenA) {
                setAllowanceA(amountParsed);
                setNeedsApprovalA(false);
            } else {
                setAllowanceB(amountParsed);
                setNeedsApprovalB(false);
            }
        } catch (err) {
            console.error('Error approving token:', err);
        }
    };

    const checkLPTokenBalance = async (tokenSymbolA, tokenSymbolB) => {
        try {
            const pairAddress = await getPairAddress(tokenSymbolA, tokenSymbolB);
            if (!pairAddress || pairAddress === ethers.constants.AddressZero) {
                setNoLiquidity(true);
                return;
            }

            const pairContract = new ethers.Contract(pairAddress, UniswapV2PairABI, provider);
            const balance = await pairContract.balanceOf(account);
            setLpBalance(ethers.utils.formatUnits(balance, 18));
            setNoLiquidity(false);
        } catch (err) {
            console.error('Error fetching LP token balance:', err);
            setNoLiquidity(false);
        }
    };

    const calculateExchangeRate = async (tokenSymbolA, tokenSymbolB) => {
        try {
            const pairAddress = await getPairAddress(tokenSymbolA, tokenSymbolB);
            if (!pairAddress || pairAddress === ethers.constants.AddressZero) {
                setExchangeRate(null);
                return;
            }

            const pairContract = new ethers.Contract(pairAddress, UniswapV2PairABI, provider);
            const reserves = await pairContract.getReserves();
            const tokenAddressA = getTokenAddress(tokenSymbolA);
            const tokenAddressB = getTokenAddress(tokenSymbolB);
            const token0 = await pairContract.token0();
            const token1 = await pairContract.token1();

            let reserveA, reserveB;

            if (tokenAddressA.toLowerCase() === token0.toLowerCase()) {
                reserveA = reserves._reserve0;
                reserveB = reserves._reserve1;
            } else {
                reserveA = reserves._reserve1;
                reserveB = reserves._reserve0;
            }

            // Calculate rate based on tokenA to tokenB
            const rate = reserveA.gt(0) ? ethers.utils.formatUnits(reserveB, getTokenDecimals(tokenSymbolB)) / ethers.utils.formatUnits(reserveA, getTokenDecimals(tokenSymbolA)) : "0";
            setExchangeRate(rate);
        } catch (err) {
            console.error('Error calculating exchange rate:', err);
            setExchangeRate(null);
        }
    };

    const getPairAddress = async (tokenSymbolA, tokenSymbolB) => {
        if ((tokenSymbolA === 'KRST' && tokenSymbolB === 'WKREST') || (tokenSymbolA === 'WKREST' && tokenSymbolB === 'KRST') || (tokenSymbolA === tokenSymbolB)) {
            return ethers.constants.AddressZero;
        }
        const factoryAddress = '0x23aAC8C182b2C2a2387868ee98C1544bF705c097';
        const factoryContract = new ethers.Contract(factoryAddress, UniswapV2FactoryABI, provider);
        const tokenAddressA = getTokenAddress(tokenSymbolA);
        const tokenAddressB = getTokenAddress(tokenSymbolB);
        if (!tokenAddressA || !tokenAddressB) throw new Error(`Token address not found for pair ${tokenSymbolA}-${tokenSymbolB}`);
        return await factoryContract.getPair(tokenAddressA, tokenAddressB);
    };

    const handleAddLiquidity = async () => {
        try {
            const router = new ethers.Contract(routerAddress, UniswapV2Router02ABI, signer);
            const tokenAddressA = getTokenAddress(tokenA);
            const tokenAddressB = getTokenAddress(tokenB);
            const amountADesired = ethers.utils.parseUnits(amountA, getTokenDecimals(tokenA));
            const amountBDesired = ethers.utils.parseUnits(amountB, getTokenDecimals(tokenB));
            const amountAMin = ethers.utils.parseUnits((amountA * 0.95).toString(), getTokenDecimals(tokenA));
            const amountBMin = ethers.utils.parseUnits((amountB * 0.95).toString(), getTokenDecimals(tokenB));

            console.log(`Adding liquidity: ${amountADesired} of ${tokenA}, ${amountBDesired} of ${tokenB}`);
            const tx = await router.addLiquidity(
                tokenAddressA,
                tokenAddressB,
                amountADesired,
                amountBDesired,
                amountAMin,
                amountBMin,
                account,
                Math.floor(Date.now() / 1000) + 60 * 10,
            );
            await tx.wait();
        } catch (err) {
            console.error('Error adding liquidity:', err);
        }
    };

    const handleAmountAChange = (value) => {
        setAmountA(value);
        if (tokenA && tokenA !== "") {
            checkIfNeedsApproval(tokenA, value, allowanceA, setNeedsApprovalA);
        }
    };

    const handleAmountBChange = (value) => {
        setAmountB(value);
        if (tokenB && tokenB !== "") {
            checkIfNeedsApproval(tokenB, value, allowanceB, setNeedsApprovalB);
        }
    };

    const renderButton = () => {
        if (needsApprovalA && tokenA) {
            console.log(`Needs approval for tokenA: ${tokenA}`);
            return (
                <AddLiquidityButton onClick={() => handleApprove(tokenA, amountA)} disabled={!!error || !tokenA || !amountA}>
                    Approve {tokens[getTokenAddress(tokenA)]?.symbol}
                </AddLiquidityButton>
            );
        }
        if (needsApprovalB && tokenB) {
            console.log(`Needs approval for tokenB: ${tokenB}`);
            return (
                <AddLiquidityButton onClick={() => handleApprove(tokenB, amountB)} disabled={!!error || !tokenB || !amountB}>
                    Approve {tokens[getTokenAddress(tokenB)]?.symbol}
                </AddLiquidityButton>
            );
        }
        return (
            <AddLiquidityButton onClick={handleAddLiquidity} disabled={!!error || !tokenA || !tokenB || !amountA || !amountB}>
                Add Liquidity
            </AddLiquidityButton>
        );
    };

    return (
        <AddLiquidityContainer>
            <h2>Add Liquidity</h2>
            <AddLiquidityInputContainer>
                <select value={tokenA} onChange={(e) => { onTokenSelection(e.target.value, tokenB); if (e.target.value !== "") checkAllowance(e.target.value, setAllowanceA, setNeedsApprovalA, amountA);}}>
                    <option value="default" key="default">Select Token A</option>
                    {Object.values(tokens).map((token) => (
                        <option key={token.address} value={token.symbol}>{token.symbol}</option>
                    ))}
                </select>
                {tokenA && (
                    <TokenInfo>
                        <img src={tokens[getTokenAddress(tokenA)]?.logo} alt="" width="20" />
                        Balance: {balanceA}
                    </TokenInfo>
                )}
                <input
                    type="text"
                    placeholder="Amount A"
                    value={amountA}
                    onChange={(e) => handleAmountAChange(e.target.value)}
                />
            </AddLiquidityInputContainer>
            <AddLiquidityInputContainer>
                <select value={tokenB} onChange={(e) => { onTokenSelection(tokenA, e.target.value); if (e.target.value !== "") checkAllowance(e.target.value, setAllowanceB, setNeedsApprovalB, amountB);}}>
                    <option value="default" key="default">Select Token B</option>
                    {Object.values(tokens).map((token) => (
                        <option key={token.address} value={token.symbol}>{token.symbol}</option>
                    ))}
                </select>
                {tokenB && (
                    <TokenInfo>
                        <img src={tokens[getTokenAddress(tokenB)]?.logo} alt="" width="20" />
                        Balance: {balanceB}
                    </TokenInfo>
                )}
                <input
                    type="text"
                    placeholder="Amount B"
                    value={amountB}
                    onChange={(e) => handleAmountBChange(e.target.value)}
                />
            </AddLiquidityInputContainer>
            {noLiquidity && (
                <NoLiquidityMessage>No Pair Found! Create your own</NoLiquidityMessage>
            )}
            {error && (
                <ErrorMessage>{error}</ErrorMessage>
            )}
            <LPTokenBalance>
                LP Token Balance: {lpBalance}
            </LPTokenBalance>
            <ExchangeRate>
                Exchange Rate: 1 {tokenA} = {exchangeRate} {tokenB}
            </ExchangeRate>
            {renderButton()}
        </AddLiquidityContainer>
    );
};

export default AddLiquidityTokens;
