import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to DonnySwap</h1>
  </div>
);

export default Home;
