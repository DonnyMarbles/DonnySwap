import React, { useState, useContext, useEffect } from 'react';
import { ethers } from 'ethers';
import { Web3Context } from '../contexts/Web3Context';
import { TokenContext } from '../contexts/TokenContext';
import { ABIContext } from '../contexts/ABIContext';
import {
  SwapContainer,
  SwapInputContainer,
  TokenInfo,
  NoLiquidityMessage,
  SlippageInputContainer,
} from '../styles/SwapStyles';
import WrapUnwrap from './WrapUnwrap';
import SwapTokens from './SwapTokens';
import SwapTokensKRST from './SwapTokensKRST';

const Swap = () => {
  const { provider, account, signer } = useContext(Web3Context);
  const { tokens, routerAddress } = useContext(TokenContext);
  const { UniswapV2Router02ABI, WrappedKRESTABI, ERC20ABI } = useContext(ABIContext);
  const [tokenIn, setTokenIn] = useState('');
  const [tokenOut, setTokenOut] = useState('');
  const [amountIn, setAmountIn] = useState('');
  const [amountOut, setAmountOut] = useState('');
  const [balanceIn, setBalanceIn] = useState('');
  const [balanceOut, setBalanceOut] = useState('');
  const [slippage, setSlippage] = useState(0.5);
  const [noLiquidity, setNoLiquidity] = useState(false);

  useEffect(() => {
    if (tokenIn && account) checkBalance(tokenIn, setBalanceIn);
    if (tokenOut && account) checkBalance(tokenOut, setBalanceOut);
  }, [tokenIn, tokenOut, account]);

  const checkBalance = async (token, setBalance) => {
    try {
      const balance = token === 'KRST' 
        ? await provider.getBalance(account) 
        : await new ethers.Contract(tokens[token].address, ERC20ABI, provider).balanceOf(account);
      setBalance(ethers.utils.formatUnits(balance, 18));
    } catch (err) {
      console.error("Error fetching balance:", err);
      setBalance('');
    }
  };

  const handleTokenInChange = (e) => {
    const newTokenIn = e.target.value;
    setTokenIn(newTokenIn);
    if (newTokenIn === tokenOut) {
      setTokenOut(tokenIn); // Swap values if they are the same
    }
  };

  const handleTokenOutChange = (e) => {
    const newTokenOut = e.target.value;
    setTokenOut(newTokenOut);
    if (newTokenOut === tokenIn) {
      setTokenIn(tokenOut); // Swap values if they are the same
    }
  };

  const isWrapOrUnwrap = (tokenIn, tokenOut) => (tokenIn === 'KRST' && tokenOut === tokens['0xdd11f4e48ce3a2b9043b2b0758ce704d3fd191dc'].address) || (tokenIn === tokens['0xdd11f4e48ce3a2b9043b2b0758ce704d3fd191dc'].address && tokenOut === 'KRST');
  const isKRSTSwap = (tokenIn, tokenOut) => tokenIn === 'KRST' || tokenOut === 'KRST';

  if (!provider || !signer) {
    return <div>Loading...</div>;
  }

  return (
    <SwapContainer>
      <h2>Swap Tokens</h2>
      <SwapInputContainer>
        <select value={tokenIn} onChange={handleTokenInChange}>
          <option value="">Select Token In</option>
          {Object.keys(tokens).map(key => (
            <option key={key} value={key}>{tokens[key].symbol}</option>
          ))}
        </select>
        {tokenIn && tokens[tokenIn] && (
          <TokenInfo>
            <img src={tokens[tokenIn].logo} alt="Token Logo" width="20" />
            Balance: <span id={`balance-${tokenIn}`}>{balanceIn}</span>
          </TokenInfo>
        )}
        <input type="text" placeholder="Amount In" value={amountIn} onChange={(e) => setAmountIn(e.target.value)} />
      </SwapInputContainer>
      <SwapInputContainer>
        <select value={tokenOut} onChange={handleTokenOutChange}>
          <option value="">Select Token Out</option>
          {Object.keys(tokens).map(key => (
            <option key={key} value={key}>{tokens[key].symbol}</option>
          ))}
        </select>
        {tokenOut && tokens[tokenOut] && (
          <TokenInfo>
            <img src={tokens[tokenOut].logo} alt="Token Logo" width="20" />
            Balance: <span id={`balance-${tokenOut}`}>{balanceOut}</span>
          </TokenInfo>
        )}
        <input type="text" placeholder="Amount Out" value={amountOut} readOnly />
      </SwapInputContainer>
      {isWrapOrUnwrap(tokenIn, tokenOut) ? (
        <WrapUnwrap
          tokenIn={tokenIn}
          tokenOut={tokenOut}
          amountIn={amountIn}
          amountOut={amountOut}
          setAmountOut={setAmountOut}
          provider={provider}
          WKRESTAddress={tokens['0xdd11f4e48ce3a2b9043b2b0758ce704d3fd191dc'].address}
          WrappedKRESTABI={WrappedKRESTABI}
        />
      ) : isKRSTSwap(tokenIn, tokenOut) ? (
        <SwapTokensKRST
          tokenIn={tokenIn}
          tokenOut={tokenOut}
          amountIn={amountIn}
          amountOut={amountOut}
          setAmountOut={setAmountOut}
          slippage={slippage}
          signer={signer}
          routerAddress={routerAddress}
          UniswapV2Router02ABI={UniswapV2Router02ABI}
          WKRESTAddress={tokens['0xdd11f4e48ce3a2b9043b2b0758ce704d3fd191dc'].address}
          account={account}
        />
      ) : (
        <SwapTokens
          tokenIn={tokenIn}
          tokenOut={tokenOut}
          amountIn={amountIn}
          amountOut={amountOut}
          setAmountOut={setAmountOut}
          slippage={slippage}
          signer={signer}
          routerAddress={routerAddress}
          UniswapV2Router02ABI={UniswapV2Router02ABI}
          account={account}
        />
      )}
      <SlippageInputContainer>
        <label htmlFor="slippage">Slippage Tolerance (%)</label>
        <input type="number" id="slippage" value={slippage} onChange={(e) => setSlippage(e.target.value)} step="0.1" min="0" />
      </SlippageInputContainer>
      {noLiquidity && <NoLiquidityMessage>No Liquidity Pool Found</NoLiquidityMessage>}
    </SwapContainer>
  );
};

export default Swap;
