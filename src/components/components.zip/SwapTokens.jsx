import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import { SwapButton } from '../styles/SwapStyles';

const SwapTokens = ({ 
  amountIn, 
  amountOut, 
  setAmountOut, 
  slippage, 
  tokenIn, 
  tokenOut, 
  signer, 
  routerAddress, 
  UniswapV2Router02ABI,
  account
}) => {
  const [exchangeRate, setExchangeRate] = useState({ text: '', rate: 0 });

  useEffect(() => {
    const fetchExchangeRate = async () => {
      try {
        const contract = new ethers.Contract(routerAddress, UniswapV2Router02ABI, signer);
        const amounts = await contract.getAmountsOut(
          ethers.utils.parseUnits(amountIn, 18),
          [tokenIn, tokenOut]
        );

        const rate = amounts[1] / amounts[0];

        setExchangeRate({
          text: `1 ${tokenIn} = ${rate.toFixed(8)} ${tokenOut}`,
          rate,
        });

        setAmountOut((amountIn * rate).toFixed(8));
      } catch (err) {
        console.error("Error fetching exchange rate:", err);
        setExchangeRate({ text: '', rate: 0 });
      }
    };

    if (amountIn && tokenIn && tokenOut) {
      fetchExchangeRate();
    }
  }, [amountIn, tokenIn, tokenOut, signer, routerAddress, UniswapV2Router02ABI, setAmountOut]);

  const handleSwapTokens = async () => {
    try {
      if (!amountIn || parseFloat(amountIn) <= 0) {
        alert('Please enter a valid amount');
        return;
      }

      const contract = new ethers.Contract(routerAddress, UniswapV2Router02ABI, signer);
      const tx = await contract.swapExactTokensForTokens(
        ethers.utils.parseUnits(amountIn, 18),
        ethers.utils.parseUnits((amountOut * (1 - slippage / 100)).toFixed(8), 18),
        [tokenIn, tokenOut],
        account,
        Math.floor(Date.now() / 1000) + 60 * 20 // 20 minutes from the current Unix time
      );
      await tx.wait();
      alert('Tokens swapped successfully');
    } catch (err) {
      console.error("Error swapping tokens:", err);
      alert(`Error swapping tokens: ${err.message}`);
    }
  };

  return (
    <>
      <SwapButton onClick={handleSwapTokens}>
        Swap Tokens
      </SwapButton>
      <div>{exchangeRate.text}</div>
    </>
  );
};

export default SwapTokens;
