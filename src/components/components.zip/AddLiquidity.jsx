import React, { useState, useContext } from 'react';
import AddLiquidityTokens from './AddLiquidityTokens';
import AddLiquidityKRST from './AddLiquidityKRST';
import { TokenContext } from '../contexts/TokenContext';

const AddLiquidity = () => {
  const { tokens } = useContext(TokenContext);
  const [tokenA, setTokenA] = useState('');
  const [tokenB, setTokenB] = useState('');
  const [error, setError] = useState('');

  const handleTokenAChange = (e) => {
    const newTokenA = e.target.value;
    if (newTokenA !== 'default') {
      if (newTokenA === tokenB) {
        setTokenA(tokenB); // Swap values if they are the same
        setTokenB(tokenA);
      } else {
        setTokenA(newTokenA);
      }
    }
    validateTokens(newTokenA, tokenB);
  };

  const handleTokenBChange = (e) => {
    const newTokenB = e.target.value;
    if (newTokenB !== 'default') {
      if (newTokenB === tokenA) {
        setTokenB(tokenA); // Swap values if they are the same
        setTokenA(tokenB);
      } else {
        setTokenB(newTokenB);
      }
    }
    validateTokens(tokenA, newTokenB);
  };

  const validateTokens = (selectedTokenA, selectedTokenB) => {
    if (selectedTokenA === 'default' || selectedTokenB === 'default') {
      setError('');
      return;
    }

    if (selectedTokenA === selectedTokenB ||
      (selectedTokenA === 'KRST' && selectedTokenB === 'WKREST') ||
      (selectedTokenA === 'WKREST' && selectedTokenB === 'KRST')) {
      setError('Invalid token pair selected.');
    } else {
      setError('');
    }
  };

  const isKRSTPair = tokenA === 'KRST' || tokenB === 'KRST';

  return (
    <div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {isKRSTPair ? (
        <AddLiquidityKRST tokenA={tokenA} tokenB={tokenB} onTokenSelection={(a, b) => { handleTokenAChange({ target: { value: a } }); handleTokenBChange({ target: { value: b } }); }} error={error} />
      ) : (
        <AddLiquidityTokens tokenA={tokenA} tokenB={tokenB} onTokenSelection={(a, b) => { handleTokenAChange({ target: { value: a } }); handleTokenBChange({ target: { value: b } }); }} error={error} />
      )}
    </div>
  );
};

export default AddLiquidity;
