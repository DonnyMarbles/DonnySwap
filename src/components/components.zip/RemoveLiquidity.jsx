import React, { useState, useContext, useEffect } from 'react';
import { ethers } from 'ethers';
import { Web3Context } from '../contexts/Web3Context';
import { TokenContext } from '../contexts/TokenContext';
import { ABIContext } from '../contexts/ABIContext';
import {
  RemoveLiquidityContainer,
  RemoveLiquidityInputContainer,
  RemoveLiquidityButton,
  TokenInfo,
  LPTokenBalance,
  NoLiquidityMessage,
} from '../styles/RemoveLiquidityStyles';

const RemoveLiquidity = () => {
  const { provider, signer, account } = useContext(Web3Context);
  const { UniswapV2Router02ABI, UniswapV2PairABI, UniswapV2FactoryABI, ERC20ABI } = useContext(ABIContext);
  const { tokens, routerAddress } = useContext(TokenContext);
  const [tokenA, setTokenA] = useState('');
  const [tokenB, setTokenB] = useState('');
  const [lpTokenBalance, setLpTokenBalance] = useState('');
  const [amountLP, setAmountLP] = useState('');
  const [noLiquidity, setNoLiquidity] = useState(false);
  const [buttonText, setButtonText] = useState('Remove Liquidity');

  useEffect(() => {
    if (tokenA && tokenB && account) {
      checkLPTokenBalance(tokenA, tokenB);
    }
  }, [tokenA, tokenB, account]);

  const checkLPTokenBalance = async (tokenA, tokenB) => {
    try {
      const pairAddress = await getPairAddress(tokenA, tokenB);
      if (!pairAddress || pairAddress === ethers.constants.AddressZero) {
        setNoLiquidity(true);
        setLpTokenBalance('');
        return;
      }

      const pairContract = new ethers.Contract(pairAddress, UniswapV2PairABI, provider);
      const balance = await pairContract.balanceOf(account);
      setLpTokenBalance(ethers.utils.formatUnits(balance, 18));
      setNoLiquidity(false);
    } catch (err) {
      console.error("Error fetching LP token balance:", err);
      setLpTokenBalance('');
      setNoLiquidity(false);
    }
  };

  const getPairAddress = async (tokenA, tokenB) => {
    const factoryAddress = "0xE8b18dDde112F880607062EDF3DC6B3078FfE46F";
    const factoryContract = new ethers.Contract(factoryAddress, UniswapV2FactoryABI, provider);
    return await factoryContract.getPair(tokenA, tokenB);
  };

  const handleRemoveLiquidity = async () => {
    try {
      const amountLPDesired = ethers.utils.parseUnits(amountLP, 18);

      const contract = new ethers.Contract(routerAddress, UniswapV2Router02ABI, signer);

      const pairAddress = await getPairAddress(tokenA, tokenB);
      if (!pairAddress || pairAddress === ethers.constants.AddressZero) {
        setNoLiquidity(true);
        return;
      }

      const tx = await contract.removeLiquidity(
        tokenA,
        tokenB,
        amountLPDesired,
        0, // Min amount of tokenA
        0, // Min amount of tokenB
        account,
        Math.floor(Date.now() / 1000) + 60 * 20 // 20 minutes from the current Unix time
      );
      await tx.wait();

      alert('Liquidity removed successfully');
    } catch (err) {
      console.error("Error removing liquidity:", err);
      alert(`Error removing liquidity: ${err.message}`);
    }
  };

  return (
    <RemoveLiquidityContainer>
      <h2>Remove Liquidity</h2>
      <RemoveLiquidityInputContainer>
        <select value={tokenA} onChange={(e) => setTokenA(e.target.value)}>
          <option value="">Select Token A</option>
          {Object.keys(tokens).map((key) => (
            <option key={key} value={tokens[key].address}>{tokens[key].symbol}</option>
          ))}
        </select>
        <select value={tokenB} onChange={(e) => setTokenB(e.target.value)}>
          <option value="">Select Token B</option>
          {Object.keys(tokens).map((key) => (
            <option key={key} value={tokens[key].address}>{tokens[key].symbol}</option>
          ))}
        </select>
        <TokenInfo>
          <img src={tokens[tokenA]?.logo} alt="" width="20" />
          <img src={tokens[tokenB]?.logo} alt="" width="20" />
          LP Token Balance: {lpTokenBalance}
        </TokenInfo>
        <input
          type="text"
          placeholder="Amount of LP Tokens"
          value={amountLP}
          onChange={(e) => setAmountLP(e.target.value)}
        />
      </RemoveLiquidityInputContainer>
      <RemoveLiquidityButton onClick={handleRemoveLiquidity} disabled={!lpTokenBalance || noLiquidity}>
        {buttonText}
      </RemoveLiquidityButton>
      {noLiquidity && (
        <NoLiquidityMessage>No Pair Found! Create your own</NoLiquidityMessage>
      )}
    </RemoveLiquidityContainer>
  );
};

export default RemoveLiquidity;
