import React, { useState, useContext, useEffect } from 'react';
import { ethers } from 'ethers';
import { Web3Context } from '../contexts/Web3Context';
import { TokenContext } from '../contexts/TokenContext';
import { ABIContext } from '../contexts/ABIContext';
import {
  AddLiquidityContainer,
  AddLiquidityInputContainer,
  AddLiquidityButton,
  TokenInfo,
  NoLiquidityMessage,
  ErrorMessage,
} from '../styles/AddLiquidityStyles';

const AddLiquidityKRST = ({ tokenA, tokenB, onTokenSelection, error }) => {
  const { provider, signer, account } = useContext(Web3Context);
  const { UniswapV2Router02ABI, UniswapV2PairABI, UniswapV2FactoryABI, ERC20ABI } = useContext(ABIContext);
  const { tokens, routerAddress } = useContext(TokenContext);
  const [amountA, setAmountA] = useState('');
  const [amountB, setAmountB] = useState('');
  const [balanceA, setBalanceA] = useState('');
  const [balanceB, setBalanceB] = useState('');
  const [noLiquidity, setNoLiquidity] = useState(false);

  useEffect(() => {
    if (tokenA && account) {
      checkBalance(tokenA, setBalanceA);
    }
    if (tokenB && account) {
      checkBalance(tokenB, setBalanceB);
    }
    if (tokenA && tokenB && !(tokenA === tokenB) && !((tokenA === 'KRST' && tokenB === 'WKREST') || (tokenA === 'WKREST' && tokenB === 'KRST'))) {
      checkLPTokenBalance(tokenA, tokenB);
    }
  }, [tokenA, tokenB, account]);

  const checkBalance = async (token, setBalance) => {
    try {
      let balance;
      if (token === 'KRST') {
        balance = await provider.getBalance(account);
      } else {
        const contract = new ethers.Contract(token, ERC20ABI, provider);
        balance = await contract.balanceOf(account);
      }
      setBalance(ethers.utils.formatUnits(balance, 18));
    } catch (err) {
      console.error('Error fetching balance:', err);
      setBalance('');
    }
  };

  const checkLPTokenBalance = async (tokenA, tokenB) => {
    try {
      const pairAddress = await getPairAddress(tokenA, tokenB);
      if (!pairAddress || pairAddress === ethers.constants.AddressZero) {
        setNoLiquidity(true);
        return;
      }

      const pairContract = new ethers.Contract(pairAddress, UniswapV2PairABI, provider);
      const balance = await pairContract.balanceOf(account);
      setNoLiquidity(false);
    } catch (err) {
      console.error('Error fetching LP token balance:', err);
      setNoLiquidity(false);
    }
  };

  const getPairAddress = async (tokenA, tokenB) => {
    if ((tokenA === 'KRST' && tokenB === 'WKREST') || (tokenA === 'WKREST' && tokenB === 'KRST') || (tokenA === tokenB)) {
      return ethers.constants.AddressZero;
    }
    const factoryAddress = '0x23aAC8C182b2C2a2387868ee98C1544bF705c097';
    const factoryContract = new ethers.Contract(factoryAddress, UniswapV2FactoryABI, provider);
    return await factoryContract.getPair(tokenA, tokenB);
  };

  const handleAddLiquidity = async () => {
    if (error) {
      return;
    }

    try {
      const amountADesired = ethers.utils.parseUnits(amountA, 18);
      const amountBDesired = ethers.utils.parseUnits(amountB, 18);

      const contract = new ethers.Contract(routerAddress, UniswapV2Router02ABI, signer);

      const [token, amountTokenDesired, amountETHDesired] = tokenA === 'KRST'
        ? [tokenB, amountBDesired, amountA]
        : [tokenA, amountADesired, amountB];

      const tx = await contract.addLiquidityETH(
        token,
        amountTokenDesired,
        0, // Min amount of token
        0, // Min amount of ETH
        account,
        Math.floor(Date.now() / 1000) + 60 * 20, // 20 minutes from the current Unix time
        { value: ethers.utils.parseUnits(amountETHDesired, 18) }
      );
      await tx.wait();

      alert('Liquidity added successfully');
    } catch (err) {
      console.error('Error adding liquidity:', err);
      alert(`Error adding liquidity: ${err.message}`);
    }
  };

  return (
    <AddLiquidityContainer>
      <h2>Add Liquidity</h2>
      <AddLiquidityInputContainer>
        <select value={tokenA} onChange={(e) => onTokenSelection(e.target.value, tokenB)}>
          <option value="">Select Token A</option>
          {Object.keys(tokens).map((key) => (
            <option key={key} value={key}>{tokens[key].symbol}</option>
          ))}
        </select>
        {tokenA && (
          <TokenInfo>
            <img src={tokens[tokenA]?.logo} alt="" width="20" />
            Balance: {balanceA}
          </TokenInfo>
        )}
        <input
          type="text"
          placeholder="Amount A"
          value={amountA}
          onChange={(e) => setAmountA(e.target.value)}
        />
      </AddLiquidityInputContainer>
      <AddLiquidityInputContainer>
        <select value={tokenB} onChange={(e) => onTokenSelection(tokenA, e.target.value)}>
          <option value="">Select Token B</option>
          {Object.keys(tokens).map((key) => (
            <option key={key} value={key}>{tokens[key].symbol}</option>
          ))}
        </select>
        {tokenB && (
          <TokenInfo>
            <img src={tokens[tokenB]?.logo} alt="" width="20" />
            Balance: {balanceB}
          </TokenInfo>
        )}
        <input
          type="text"
          placeholder="Amount B"
          value={amountB}
          onChange={(e) => setAmountB(e.target.value)}
        />
      </AddLiquidityInputContainer>
      {noLiquidity && (
        <NoLiquidityMessage>No Pair Found! Create your own</NoLiquidityMessage>
      )}
      {error && (
        <ErrorMessage>{error}</ErrorMessage>
      )}
      <AddLiquidityButton onClick={handleAddLiquidity} disabled={!!error}>
        Add Liquidity
      </AddLiquidityButton>
    </AddLiquidityContainer>
  );
};

export default AddLiquidityKRST;
